# Wallpaper App Using Pexel Api Android 
Learn How to Create Wallpaper App Using Pexel Api & Volley Library in Android Studio.

**Part 1: How to Create Pexel Api**<br/> 
Link ►  https://youtu.be/9X0SDucc428

**Part 2: How to Fetch Wallpapers in Wallpaper App Using Pexel API**<br/>
Link ►  https://youtu.be/dSD1BBi6M-I

**Part 3: How to Set Wallpaper From Wallpaper App Using Pexel API**<br/> 
Link ►  https://youtu.be/5yISxQ129eU

**Part 4: How to Download Wallpaper From Wallpaper App Using Pexel API**<br/> 
Link ►  https://youtu.be/NnDiiiVy8o4

**Part 5: How to Implement Search Category Wallpaper in Wallpaper App Using Pexel API** <br/> 
Link ►  https://youtu.be/Ygoy5J0qUS8

# Screenshots 
<p float="left">
 <img src="https://github.com/arsltech/Wallpaper-App-Using-Pexel-Api-Android-/blob/master/Screen1.png" width="200" height="400" />
 <img src="https://github.com/arsltech/Wallpaper-App-Using-Pexel-Api-Android-/blob/master/Screen2.png" width="200" height="400" />
 <img src="https://github.com/arsltech/Wallpaper-App-Using-Pexel-Api-Android-/blob/master/Screen3.png" width="200" height="400" />
 <img src="https://github.com/arsltech/Wallpaper-App-Using-Pexel-Api-Android-/blob/master/Screen4.png" width="200" height="400" />

</p>
